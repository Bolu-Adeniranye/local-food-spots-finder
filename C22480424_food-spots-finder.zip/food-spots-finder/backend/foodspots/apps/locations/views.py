from django.contrib.gis.geos import Point, Polygon
from django.contrib.gis.measure import D
from django.contrib.gis.db.models.functions import Distance
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
import logging

from .models import FoodSpot
from .serializers import FoodSpotListSerializer

logger = logging.getLogger(__name__)


class FoodSpotViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for FoodSpot with all spatial queries
    """
    queryset = FoodSpot.objects.filter(is_active=True)
    serializer_class = FoodSpotListSerializer
    
    def get_queryset(self):
        queryset = super().get_queryset()
        cuisine_type = self.request.query_params.get('cuisine_type', None)
        if cuisine_type:
            queryset = queryset.filter(cuisine_type=cuisine_type)
        return queryset
    
    def list(self, request, *args, **kwargs):
        """Get all food spots"""
        try:
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            logger.info(f"Returning {len(serializer.data)} food spots")
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in list: {str(e)}")
            return Response({'error': str(e)}, status=500)
    
    @action(detail=False, methods=['get'])
    def categories(self, request):
        """Get all cuisine categories"""
        try:
            categories = [{'value': c[0], 'label': c[1]} for c in FoodSpot.CUISINE_CHOICES]
            return Response(categories)
        except Exception as e:
            logger.error(f"Error in categories: {str(e)}")
            return Response({'error': str(e)}, status=500)
    
    @action(detail=False, methods=['post'])
    def nearest(self, request):
        """SPATIAL QUERY 1: Find nearest food spots"""
        try:
            lat = float(request.data.get('latitude'))
            lng = float(request.data.get('longitude'))
            limit = int(request.data.get('limit', 10))
            
            logger.info(f"Finding nearest {limit} spots to ({lat}, {lng})")
            
            user_location = Point(lng, lat, srid=4326)
            
            nearest_spots = FoodSpot.objects.filter(is_active=True).annotate(
                distance=Distance('location', user_location)
            ).order_by('distance')[:limit]
            
            results = []
            for spot in nearest_spots:
                results.append({
                    'id': spot.id,
                    'name': spot.name,
                    'cuisine_type': spot.cuisine_type,
                    'cuisine_display': spot.get_cuisine_type_display(),
                    'description': spot.description,
                    'address': spot.address,
                    'phone': spot.phone,
                    'rating': float(spot.rating),
                    'price_range': spot.price_range,
                    'opening_hours': spot.opening_hours,
                    'latitude': spot.location.y,
                    'longitude': spot.location.x,
                    'distance_meters': round(spot.distance.m, 2),
                    'distance_km': round(spot.distance.km, 2)
                })
            
            logger.info(f"Found {len(results)} nearest spots")
            return Response(results)
            
        except (ValueError, TypeError) as e:
            logger.error(f"Invalid parameters: {str(e)}")
            return Response({'error': 'Invalid latitude or longitude'}, status=400)
        except Exception as e:
            logger.error(f"Error in nearest: {str(e)}")
            return Response({'error': str(e)}, status=500)
    
    @action(detail=False, methods=['post'])
    def within_radius(self, request):
        """SPATIAL QUERY 2: Find spots within radius"""
        try:
            lat = float(request.data.get('latitude'))
            lng = float(request.data.get('longitude'))
            radius = float(request.data.get('radius_meters', 1000))
            cuisine_type = request.data.get('cuisine_type', None)
            
            logger.info(f"Searching within {radius}m of ({lat}, {lng}), cuisine={cuisine_type}")
            
            user_location = Point(lng, lat, srid=4326)
            
            # Use buffer distance properly
            spots = FoodSpot.objects.filter(is_active=True).annotate(
                distance=Distance('location', user_location)
            ).filter(
                distance__lte=D(m=radius)
            ).order_by('distance')
            
            if cuisine_type:
                spots = spots.filter(cuisine_type=cuisine_type)
            
            results = []
            for spot in spots:
                results.append({
                    'id': spot.id,
                    'name': spot.name,
                    'cuisine_type': spot.cuisine_type,
                    'cuisine_display': spot.get_cuisine_type_display(),
                    'description': spot.description,
                    'address': spot.address,
                    'phone': spot.phone,
                    'rating': float(spot.rating),
                    'price_range': spot.price_range,
                    'opening_hours': spot.opening_hours,
                    'latitude': spot.location.y,
                    'longitude': spot.location.x,
                    'distance_meters': round(spot.distance.m, 2),
                    'distance_km': round(spot.distance.km, 2)
                })
            
            logger.info(f"Found {len(results)} spots within radius")
            return Response(results)
            
        except (ValueError, TypeError) as e:
            logger.error(f"Invalid parameters: {str(e)}")
            return Response({'error': 'Invalid parameters'}, status=400)
        except Exception as e:
            logger.error(f"Error in within_radius: {str(e)}")
            return Response({'error': str(e)}, status=500)
    
    @action(detail=False, methods=['post'])
    def within_bounds(self, request):
        """SPATIAL QUERY 3: Find spots within polygon bounds"""
        try:
            bounds = request.data.get('bounds', [])
            
            if len(bounds) < 4:
                return Response({'error': 'Need at least 4 points'}, status=400)
            
            logger.info(f"Searching within polygon with {len(bounds)} points")
            
            points = [(float(c[1]), float(c[0])) for c in bounds]
            if points[0] != points[-1]:
                points.append(points[0])
            
            polygon = Polygon(points, srid=4326)
            spots = FoodSpot.objects.filter(is_active=True, location__within=polygon)
            
            results = []
            for spot in spots:
                results.append({
                    'id': spot.id,
                    'name': spot.name,
                    'cuisine_type': spot.cuisine_type,
                    'cuisine_display': spot.get_cuisine_type_display(),
                    'description': spot.description,
                    'address': spot.address,
                    'phone': spot.phone,
                    'rating': float(spot.rating),
                    'price_range': spot.price_range,
                    'opening_hours': spot.opening_hours,
                    'latitude': spot.location.y,
                    'longitude': spot.location.x
                })
            
            logger.info(f"Found {len(results)} spots within bounds")
            return Response(results)
            
        except Exception as e:
            logger.error(f"Error in within_bounds: {str(e)}")
            return Response({'error': str(e)}, status=400)