from rest_framework import serializers
from rest_framework_gis.serializers import GeoFeatureModelSerializer
from .models import FoodSpot


class FoodSpotSerializer(GeoFeatureModelSerializer):
    """
    GeoJSON serializer for FoodSpot model.
    Outputs in GeoJSON format for easy mapping with Leaflet.
    """
    
    latitude = serializers.SerializerMethodField()
    longitude = serializers.SerializerMethodField()
    cuisine_display = serializers.CharField(source='get_cuisine_type_display', read_only=True)
    price_display = serializers.CharField(source='get_price_range_display', read_only=True)
    
    class Meta:
        model = FoodSpot
        geo_field = 'location'
        fields = [
            'id', 'name', 'cuisine_type', 'cuisine_display', 
            'description', 'address', 'phone', 'website',
            'rating', 'price_range', 'price_display', 'opening_hours',
            'latitude', 'longitude', 'is_active', 'created_at'
        ]
    
    def get_latitude(self, obj):
        return obj.location.y if obj.location else None
    
    def get_longitude(self, obj):
        return obj.location.x if obj.location else None


class FoodSpotListSerializer(serializers.ModelSerializer):
    """
    Simple list serializer without GeoJSON format.
    """
    
    cuisine_display = serializers.CharField(source='get_cuisine_type_display', read_only=True)
    latitude = serializers.SerializerMethodField()
    longitude = serializers.SerializerMethodField()
    
    class Meta:
        model = FoodSpot
        fields = [
            'id', 'name', 'cuisine_type', 'cuisine_display',
            'address', 'rating', 'price_range', 'latitude', 'longitude'
        ]
    
    def get_latitude(self, obj):
        return obj.location.y if obj.location else None
    
    def get_longitude(self, obj):
        return obj.location.x if obj.location else None