// Global Variables
let map, userMarker = null, userLocation = null, searchCircle = null, foodSpotsLayer = null;
let drawingPolygon = false, polygonPoints = [], tempPolygon = null, drawnMarkers = [];
let distanceLines = []; // Store distance lines
const API_BASE = '/api';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing Food Spots Finder...');
    initMap();
    loadCategories();
    loadAllFoodSpots();
    initEventListeners();
});

// Initialize Leaflet Map
function initMap() {
    console.log('🗺️ Initializing map...');
    map = L.map('map').setView([53.349805, -6.260310], 13);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);
    
    foodSpotsLayer = L.layerGroup().addTo(map);
    map.on('click', onMapClick);
    console.log('✅ Map initialized successfully');
}

// Load Cuisine Categories
async function loadCategories() {
    try {
        console.log('📋 Loading categories...');
        const response = await fetch(`${API_BASE}/foodspots/categories/`);
        const categories = await response.json();
        
        const select = document.getElementById('cuisineFilter');
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.value;
            option.textContent = cat.label;
            select.appendChild(option);
        });
        console.log(`✅ Loaded ${categories.length} categories`);
    } catch (error) {
        console.error('❌ Error loading categories:', error);
        showNotification('Failed to load categories', 'error');
    }
}

// Load All Food Spots
async function loadAllFoodSpots() {
    showLoading(true);
    try {
        console.log('🔍 Loading all food spots...');
        const cuisineFilter = document.getElementById('cuisineFilter').value;
        let url = `${API_BASE}/foodspots/`;
        if (cuisineFilter) url += `?cuisine_type=${cuisineFilter}`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const spots = await response.json();
        console.log(`✅ Loaded ${spots.length} food spots`);
        
        if (Array.isArray(spots) && spots.length > 0) {
            displayFoodSpots(spots);
            updateResultsInfo(`Showing ${spots.length} food spots`);
            document.getElementById('totalSpots').textContent = spots.length;
        } else {
            updateResultsInfo('No food spots available');
            document.getElementById('spotsContainer').innerHTML = 
                '<p class="text-center text-muted py-3">No food spots found</p>';
        }
    } catch (error) {
        console.error('❌ Error loading food spots:', error);
        showNotification('Failed to load food spots', 'error');
    } finally {
        showLoading(false);
    }
}

// Display Food Spots on Map
function displayFoodSpots(spots) {
    console.log(`🍕 Displaying ${spots.length} spots on map...`);
    foodSpotsLayer.clearLayers();
    clearDistanceLines();
    
    if (!Array.isArray(spots) || spots.length === 0) {
        console.warn('⚠️ No spots to display');
        return;
    }
    
    spots.forEach(spot => {
        try {
            const icon = L.divIcon({
                className: 'custom-marker',
                html: `<div style="background: white; border-radius: 50%; padding: 5px; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                        <i class="fas fa-utensils" style="color: #0d6efd; font-size: 20px;"></i>
                       </div>`,
                iconSize: [35, 35],
                iconAnchor: [17, 35]
            });
            
            const marker = L.marker([spot.latitude, spot.longitude], { icon: icon }).addTo(foodSpotsLayer);
            
            const popupContent = `
                <div class="popup-title">${spot.name}</div>
                <div class="popup-info"><strong>🍽️ Cuisine:</strong> ${spot.cuisine_display || spot.cuisine_type}</div>
                <div class="popup-info"><strong>⭐ Rating:</strong> <span class="popup-rating">${spot.rating}</span></div>
                <div class="popup-info"><strong>💰 Price:</strong> ${spot.price_range}</div>
                <div class="popup-info"><strong>📍 Address:</strong> ${spot.address}</div>
                <div class="popup-info"><strong>📞 Phone:</strong> ${spot.phone || 'N/A'}</div>
                <div class="popup-info"><strong>🕒 Hours:</strong> ${spot.opening_hours}</div>
                ${spot.distance_km ? `<div class="popup-info spot-distance"><strong>📏 Distance:</strong> ${spot.distance_km} km (${spot.distance_meters}m)</div>` : ''}
            `;
            
            marker.bindPopup(popupContent);
            marker.spotData = spot;
        } catch (error) {
            console.error('❌ Error displaying spot:', spot, error);
        }
    });
    
    console.log('✅ All spots displayed on map');
}

// Clear Distance Lines
function clearDistanceLines() {
    distanceLines.forEach(line => map.removeLayer(line));
    distanceLines = [];
}

// Draw Distance Line from User to Spot
function drawDistanceLine(fromLatLng, toLatLng, distance, index) {
    // Create polyline
    const line = L.polyline([fromLatLng, toLatLng], {
        color: '#28a745',
        weight: 3,
        opacity: 0.7,
        dashArray: '10, 10'
    }).addTo(map);
    
    // Add distance label
    const midpoint = [
        (fromLatLng.lat + toLatLng.lat) / 2,
        (fromLatLng.lng + toLatLng.lng) / 2
    ];
    
    const label = L.marker(midpoint, {
        icon: L.divIcon({
            className: 'distance-label',
            html: `<div style="background: white; padding: 4px 8px; border-radius: 12px; border: 2px solid #28a745; font-weight: bold; font-size: 11px; box-shadow: 0 2px 6px rgba(0,0,0,0.3); white-space: nowrap;">
                    #${index + 1}: ${distance.toFixed(2)} km
                   </div>`,
            iconSize: [0, 0]
        })
    }).addTo(map);
    
    distanceLines.push(line);
    distanceLines.push(label);
}

// Display Results List in Sidebar
function displayResultsList(spots) {
    const container = document.getElementById('spotsContainer');
    container.innerHTML = '';
    
    if (!Array.isArray(spots) || spots.length === 0) {
        container.innerHTML = '<p class="text-center text-muted py-3"><i class="fas fa-search fa-2x mb-2 d-block"></i>No results found</p>';
        return;
    }
    
    console.log(`📝 Displaying ${spots.length} spots in list...`);
    
    spots.forEach((spot, index) => {
        const card = document.createElement('div');
        card.className = 'spot-card';
        card.style.animationDelay = `${index * 0.05}s`;
        card.innerHTML = `
            <div class="d-flex justify-content-between align-items-start">
                <h6 class="mb-1"><i class="fas fa-utensils me-2"></i>${spot.name}</h6>
                ${spot.distance_km ? `<span class="badge bg-success">#${index + 1}</span>` : ''}
            </div>
            <small class="d-block text-muted"><i class="fas fa-map-marker-alt me-1"></i>${spot.address}</small>
            <div class="mt-2">
                <span class="spot-rating">⭐ ${spot.rating}</span>
                <span class="mx-2">|</span>
                <span>💰 ${spot.price_range}</span>
            </div>
            ${spot.distance_km ? `<div class="spot-distance mt-2"><i class="fas fa-route me-1"></i>${spot.distance_km} km away (${spot.distance_meters}m)</div>` : ''}
            <span class="spot-badge mt-2">${spot.cuisine_display || spot.cuisine_type}</span>
        `;
        
        card.addEventListener('click', () => {
            foodSpotsLayer.eachLayer(layer => {
                if (layer.spotData && layer.spotData.id === spot.id) {
                    map.setView(layer.getLatLng(), 16);
                    layer.openPopup();
                }
            });
        });
        
        container.appendChild(card);
    });
}

// Handle Map Click
function onMapClick(e) {
    const dropPinBtn = document.getElementById('dropPinBtn');
    
    if (dropPinBtn.classList.contains('active')) {
        dropUserPin(e.latlng);
        dropPinBtn.classList.remove('active');
    } else if (drawingPolygon) {
        addPolygonPoint(e.latlng);
    }
}

// Drop User Location Pin
function dropUserPin(latlng) {
    console.log(`📍 Dropping pin at: ${latlng.lat}, ${latlng.lng}`);
    
    if (userMarker) map.removeLayer(userMarker);
    clearDistanceLines();
    
    const redIcon = L.divIcon({
        className: 'user-pin-icon',
        html: `<div style="background: #dc3545; border-radius: 50%; padding: 8px; border: 4px solid white; box-shadow: 0 4px 15px rgba(220,53,69,0.5);">
                <i class="fas fa-map-pin" style="color: white; font-size: 22px;"></i>
               </div>`,
        iconSize: [40, 45],
        iconAnchor: [20, 45]
    });
    
    userMarker = L.marker(latlng, { icon: redIcon }).addTo(map);
    userMarker.bindPopup('<b>📍 Your Location</b><br>Click search buttons to find nearby spots').openPopup();
    userLocation = latlng;
    
    document.getElementById('findNearestBtn').disabled = false;
    document.getElementById('searchRadiusBtn').disabled = false;
    
    updateResultsInfo('✅ Pin dropped! Now search for nearby spots.');
    showNotification('Location pin dropped successfully!', 'success');
}

// Find Nearest Food Spots
async function findNearest() {
    if (!userLocation) {
        showNotification('Please drop a location pin first!', 'warning');
        return;
    }
    
    const limit = parseInt(document.getElementById('nearestLimit').value);
    console.log(`🔍 Finding nearest ${limit} spots...`);
    showLoading(true);
    clearDistanceLines();
    
    try {
        const response = await fetch(`${API_BASE}/foodspots/nearest/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                latitude: userLocation.lat,
                longitude: userLocation.lng,
                limit: limit
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Search failed');
        }
        
        const results = await response.json();
        console.log(`✅ Found ${results.length} nearest spots`);
        
        if (Array.isArray(results) && results.length > 0) {
            displayFoodSpots(results);
            displayResultsList(results);
            
            // Draw distance lines
            results.forEach((spot, index) => {
                const spotLatLng = L.latLng(spot.latitude, spot.longitude);
                drawDistanceLine(userLocation, spotLatLng, spot.distance_km, index);
            });
            
            updateResultsInfo(`✅ Found ${results.length} nearest spots`);
            showNotification(`Found ${results.length} nearest spots with distance lines!`, 'success');
            
            const bounds = L.latLngBounds([userLocation]);
            results.forEach(spot => bounds.extend([spot.latitude, spot.longitude]));
            map.fitBounds(bounds, { padding: [80, 80] });
        } else {
            updateResultsInfo('❌ No food spots found nearby');
            displayResultsList([]);
            showNotification('No spots found nearby', 'info');
        }
    } catch (error) {
        console.error('❌ Error finding nearest:', error);
        showNotification(`Error: ${error.message}`, 'error');
        updateResultsInfo('❌ Search failed');
    } finally {
        showLoading(false);
    }
}

// Search Within Radius
async function searchWithinRadius() {
    if (!userLocation) {
        showNotification('Please drop a location pin first!', 'warning');
        return;
    }
    
    const radius = document.getElementById('radiusSlider').value;
    const cuisineType = document.getElementById('cuisineFilter').value;
    
    console.log(`🔍 Searching within ${radius}m radius...`);
    showLoading(true);
    clearDistanceLines();
    
    try {
        const requestBody = {
            latitude: userLocation.lat,
            longitude: userLocation.lng,
            radius_meters: parseInt(radius)
        };
        if (cuisineType) requestBody.cuisine_type = cuisineType;
        
        const response = await fetch(`${API_BASE}/foodspots/within_radius/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Search failed');
        }
        
        const results = await response.json();
        console.log(`✅ Found ${results.length} spots within radius`);
        
        // Draw search circle
        if (searchCircle) map.removeLayer(searchCircle);
        searchCircle = L.circle(userLocation, {
            radius: parseInt(radius),
            color: '#0d6efd',
            fillColor: '#0d6efd',
            fillOpacity: 0.15,
            weight: 3,
            dashArray: '10, 10'
        }).addTo(map);
        
        if (Array.isArray(results) && results.length > 0) {
            displayFoodSpots(results);
            displayResultsList(results);
            
            // Draw distance lines
            results.forEach((spot, index) => {
                const spotLatLng = L.latLng(spot.latitude, spot.longitude);
                drawDistanceLine(userLocation, spotLatLng, spot.distance_km, index);
            });
            
            updateResultsInfo(`✅ Found ${results.length} spots within ${radius}m`);
            showNotification(`Found ${results.length} spots in radius!`, 'success');
        } else {
            updateResultsInfo(`❌ No spots found within ${radius}m`);
            displayResultsList([]);
            showNotification('No spots found in this radius', 'info');
        }
        
        map.fitBounds(searchCircle.getBounds(), { padding: [80, 80] });
    } catch (error) {
        console.error('❌ Error searching radius:', error);
        showNotification(`Error: ${error.message}`, 'error');
        updateResultsInfo('❌ Search failed');
    } finally {
        showLoading(false);
    }
}

// Toggle Drawing Mode
function toggleDrawBounds() {
    const btn = document.getElementById('drawBoundsBtn');
    
    if (!drawingPolygon) {
        drawingPolygon = true;
        polygonPoints = [];
        btn.classList.add('active');
        btn.innerHTML = '<i class="fas fa-check me-2"></i> Finish Drawing';
        updateResultsInfo('🎨 Click on map to draw search area. Click "Finish" when done.');
        showNotification('Click on the map to draw your search area', 'info');
    } else {
        if (polygonPoints.length >= 3) {
            searchWithinBounds();
        } else {
            showNotification('Please draw at least 3 points!', 'warning');
        }
        drawingPolygon = false;
        btn.classList.remove('active');
        btn.innerHTML = '<i class="fas fa-draw-polygon me-2"></i> Draw Search Area';
    }
}

// Add Point to Polygon
function addPolygonPoint(latlng) {
    console.log(`📍 Adding polygon point: ${latlng.lat}, ${latlng.lng}`);
    polygonPoints.push(latlng);
    
    if (tempPolygon) map.removeLayer(tempPolygon);
    
    if (polygonPoints.length >= 2) {
        tempPolygon = L.polygon(polygonPoints, {
            color: '#ffc107',
            fillColor: '#ffc107',
            fillOpacity: 0.2,
            weight: 3,
            dashArray: '10, 10'
        }).addTo(map);
    }
    
    const marker = L.circleMarker(latlng, {
        radius: 6,
        color: '#ffc107',
        fillColor: '#ffc107',
        fillOpacity: 1,
        weight: 2
    }).addTo(map);
    
    drawnMarkers.push(marker);
    updateResultsInfo(`📍 ${polygonPoints.length} points drawn. ${polygonPoints.length >= 3 ? 'Click "Finish" to search.' : 'Keep drawing...'}`);
}

// Search Within Bounds
async function searchWithinBounds() {
    console.log('🔍 Searching within drawn bounds...');
    showLoading(true);
    clearDistanceLines();
    
    try {
        const bounds = polygonPoints.map(p => [p.lat, p.lng]);
        bounds.push([polygonPoints[0].lat, polygonPoints[0].lng]);
        
        const response = await fetch(`${API_BASE}/foodspots/within_bounds/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bounds: bounds })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Search failed');
        }
        
        const results = await response.json();
        console.log(`✅ Found ${results.length} spots within bounds`);
        
        if (Array.isArray(results) && results.length > 0) {
            displayFoodSpots(results);
            displayResultsList(results);
            updateResultsInfo(`✅ Found ${results.length} spots in drawn area`);
            showNotification(`Found ${results.length} spots in area!`, 'success');
        } else {
            updateResultsInfo('❌ No spots found in drawn area');
            displayResultsList([]);
            showNotification('No spots found in this area', 'info');
        }
    } catch (error) {
        console.error('❌ Error searching bounds:', error);
        showNotification(`Error: ${error.message}`, 'error');
        updateResultsInfo('❌ Search failed');
    } finally {
        showLoading(false);
    }
}

// Clear All
function clearAll() {
    console.log('🧹 Clearing all...');
    
    if (userMarker) { map.removeLayer(userMarker); userMarker = null; }
    userLocation = null;
    if (searchCircle) { map.removeLayer(searchCircle); searchCircle = null; }
    if (tempPolygon) { map.removeLayer(tempPolygon); tempPolygon = null; }
    
    clearDistanceLines();
    drawnMarkers.forEach(marker => map.removeLayer(marker));
    drawnMarkers = [];
    polygonPoints = [];
    drawingPolygon = false;
    
    document.getElementById('cuisineFilter').value = '';
    document.getElementById('radiusSlider').value = 1000;
    document.getElementById('radiusValue').textContent = '1000';
    document.getElementById('nearestLimit').value = 10;
    document.getElementById('findNearestBtn').disabled = true;
    document.getElementById('searchRadiusBtn').disabled = true;
    document.getElementById('drawBoundsBtn').classList.remove('active');
    document.getElementById('drawBoundsBtn').innerHTML = '<i class="fas fa-draw-polygon me-2"></i> Draw Search Area';
    
    loadAllFoodSpots();
    showNotification('All filters cleared!', 'info');
}

// Initialize Event Listeners
function initEventListeners() {
    document.getElementById('dropPinBtn').addEventListener('click', function() {
        this.classList.toggle('active');
        updateResultsInfo(this.classList.contains('active') ? 
            '🎯 Click anywhere on the map to drop your location pin' : 
            '❌ Pin drop cancelled');
    });
    
    document.getElementById('findNearestBtn').addEventListener('click', findNearest);
    document.getElementById('searchRadiusBtn').addEventListener('click', searchWithinRadius);
    document.getElementById('drawBoundsBtn').addEventListener('click', toggleDrawBounds);
    document.getElementById('clearBtn').addEventListener('click', clearAll);
    
    document.getElementById('cuisineFilter').addEventListener('change', function() {
        if (userLocation) {
            searchWithinRadius();
        } else {
            loadAllFoodSpots();
        }
    });
    
    document.getElementById('radiusSlider').addEventListener('input', function() {
        document.getElementById('radiusValue').textContent = this.value;
    });
}

// Utility Functions
function showLoading(show) {
    document.getElementById('loadingOverlay').style.display = show ? 'flex' : 'none';
}

function updateResultsInfo(message) {
    document.getElementById('resultsCount').textContent = message;
}

function showNotification(message, type = 'info') {
    console.log(`📢 ${type.toUpperCase()}: ${message}`);
}

console.log('✅ Food Spots Finder loaded successfully!');