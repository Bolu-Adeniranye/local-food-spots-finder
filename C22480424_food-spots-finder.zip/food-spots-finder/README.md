# 🍽️ FoodSpot - Restaurant Finder

A location-based services (LBS) web application for discovering restaurants and food establishments in Dublin. Built with Django, PostGIS, and Leaflet.js.

---

## Features

### Core Functionality
- **Interactive Map**: Leaflet.js-powered map with OpenStreetMap tiles centered on Dublin
- **Multiple Cuisine Types**: Filter restaurants by cuisine (Italian, Asian, Irish, American, etc.)
- **Real-time Search**: Search restaurants by name, cuisine, or location
- **User Location**: Click anywhere on map, use GPS, or search by address
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

### Spatial Queries (PostGIS)
1. **Nearest Restaurants** - Find closest dining options using `ST_Distance` with distance calculation
2. **Radius Search** - Discover all restaurants within X kilometers using `ST_DWithin`
3. **Cuisine-Based Search** - Filter by cuisine type with calculated distances

### Additional Features
- **Restaurant Information**: Detailed popups with ratings, cuisine type, and contact details
- **Distance Display**: Accurate distance calculation in kilometers
- **Custom Markers**: Visual indicators showing different cuisine types
- **Opening Hours**: Display restaurant availability and operating hours
- **Price Range**: Filter by budget (€, €€, €€€)

---

## Technology Stack

### Backend
- **Framework**: Django 4.2 (Python 3.11)
- **Database**: PostgreSQL 15 with PostGIS 3.3 extension
- **API**: Django REST Framework
- **GIS**: GeoDjango with spatial database support

### Frontend
- **Mapping**: Leaflet.js 1.9.4
- **Tiles**: OpenStreetMap
- **Icons**: Font Awesome
- **JavaScript**: Vanilla ES6+

### Deployment
- **Containerization**: Docker & Docker Compose
- **Web Server**: Nginx
- **Database Admin**: PgAdmin 4

---

##  Prerequisites

### For Docker Deployment
- Docker Desktop 20.10+ or Docker Engine 20.10+
- Docker Compose 2.0+
- 4GB RAM minimum
- 5GB free disk space

### For Local Development
- Python 3.11+
- PostgreSQL 15+ with PostGIS 3.3+
- pip and virtualenv

---

## Quick Start (Docker)

### 1. Clone the Repository
```bash
git clone https://github.com/Bolu-Adeniranye/foodspot
cd foodspot
```

### 2. Environment Configuration
Create a `.env` file with the following variables:
```env
DATABASE_NAME=foodspot_db
DATABASE_USER=postgres
DATABASE_PASSWORD=your_password_here
DATABASE_HOST=postgis
DATABASE_PORT=5432
DJANGO_SECRET_KEY=your-secret-key-here
DEBUG=True
```

### 3. Start All Services
```bash
docker-compose up --build
```

This will:
- Create PostgreSQL database with PostGIS extension
- Set up PgAdmin4 for database management
- Build and run Django application
- Configure Nginx reverse proxy
- Load sample restaurant data

### 4. Access the Application

| Service | URL | 
|---------|-----|
| **Main Application** | http://localhost |
| **Django Admin** | http://localhost/admin | 
| **PgAdmin4** | http://localhost:5050 |
| **API Root** | http://localhost/api/restaurants/ |

### 5. Stop Services
```bash
# Stop containers
docker-compose stop

# Remove containers
docker-compose down

# Remove everything including data
docker-compose down -v
```

---


## 🔌 API Endpoints

### Base URL
```
http://localhost/api/restaurants/
```

### Available Endpoints

#### 1. List All Restaurants
```http
GET /api/restaurants/
GET /api/restaurants/?cuisine=Italian
```

#### 2. Find Nearest Restaurants
```http
GET /api/restaurants/nearest/?lat=53.3498&lng=-6.2603&limit=5
```

**Parameters:**
- `lat` (required): Latitude
- `lng` (required): Longitude
- `limit` (optional): Number of results (default: 5)
- `cuisine` (optional): Filter by cuisine type

#### 3. Restaurants Within Radius
```http
GET /api/restaurants/within_radius/?lat=53.3498&lng=-6.2603&radius=5
```

**Parameters:**
- `lat` (required): Latitude
- `lng` (required): Longitude
- `radius` (required): Radius in kilometers
- `cuisine` (optional): Filter by cuisine type

#### 4. Get Statistics
```http
GET /api/restaurants/statistics/
```

**Response:**
```json
{
  "total_restaurants": 50,
  "by_cuisine": {
    "Italian": 12,
    "Asian": 15,
    "Irish": 8,
    "American": 10,
    "Other": 5
  }
}
```

---

## Database Schema

### Restaurant Model

| Field | Type | Description | PostGIS |
|-------|------|-------------|---------|
| id | Integer | Primary key | - |
| name | CharField(200) | Restaurant name | - |
| cuisine_type | CharField(50) | Cuisine category | - |
| address | CharField(300) | Full address | - |
| phone | CharField(20) | Contact phone | - |
| **location** | **PointField** | **Lat/Lng coordinates** | **✓ SRID 4326** |
| price_range | CharField(5) | €, €€, €€€ | - |
| rating | DecimalField | User rating (0-5) | - |
| opening_hours | CharField(100) | Operating hours | - |
| description | TextField | Restaurant details | - |

### Spatial Features
- **Coordinate System**: WGS84 (SRID 4326)
- **Spatial Index**: GiST index on `location` field
- **Spatial Functions**:
  - `ST_Distance()` - Calculate distance between points
  - `ST_DWithin()` - Find points within radius

```

### Database Testing
```sql
-- Check PostGIS installation
SELECT PostGIS_Version();

-- Count restaurants by cuisine
SELECT cuisine_type, COUNT(*) 
FROM restaurants_restaurant 
GROUP BY cuisine_type;

-- Test spatial query
SELECT name, ST_AsText(location) 
FROM restaurants_restaurant 
LIMIT 5;
```

---

## Known Limitations

- Sample data limited to Dublin area
- Radius search limited to 50km maximum
- Geocoding depends on external APIs
- Basic error handling implemented

---

## Author

**Moboluwarin Adeniranye**
- Student ID: C22480424
- Email: C22480424@mytudublin.ie

---