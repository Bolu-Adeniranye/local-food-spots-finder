"""
Management command to load initial food spots data
Usage: python manage.py load_initial_data
"""
from django.core.management.base import BaseCommand
from django.contrib.gis.geos import Point
from foodspots.apps.locations.models import FoodSpot


class Command(BaseCommand):
    help = 'Loads initial food spots data into the database'

    def add_arguments(self, parser):
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing data before loading',
        )

    def handle(self, *args, **options):
        # Check if data already exists
        existing_count = FoodSpot.objects.count()
        
        if existing_count > 0 and not options['clear']:
            self.stdout.write(
                self.style.WARNING(
                    f'⚠️  Database already has {existing_count} food spots. '
                    'Use --clear flag to delete and reload.'
                )
            )
            return

        # Clear existing data if requested
        if options['clear'] and existing_count > 0:
            FoodSpot.objects.all().delete()
            self.stdout.write(self.style.SUCCESS(f'🗑️  Deleted {existing_count} existing food spots'))

        # Create food spots data
        self.stdout.write('📥 Loading initial food spots data...')
        
        spots_data = [
            {
                'name': "Mario's Italian Kitchen",
                'cuisine_type': 'italian',
                'description': 'Authentic Italian cuisine with fresh homemade pasta',
                'address': '123 Grafton Street, Dublin 2',
                'phone': '+353 1 234 5678',
                'website': 'https://marios-italian.example.com',
                'rating': 4.5,
                'price_range': '€€',
                'opening_hours': '11:00 AM - 11:00 PM',
                'location': Point(-6.260310, 53.349805, srid=4326)
            },
            {
                'name': 'Dragon Palace',
                'cuisine_type': 'chinese',
                'description': 'Traditional Chinese dishes and authentic dim sum',
                'address': "45 O'Connell Street, Dublin 1",
                'phone': '+353 1 234 5679',
                'website': 'https://dragonpalace.example.com',
                'rating': 4.2,
                'price_range': '€€',
                'opening_hours': '12:00 PM - 10:30 PM',
                'location': Point(-6.258845, 53.349562, srid=4326)
            },
            {
                'name': 'Taco Fiesta',
                'cuisine_type': 'mexican',
                'description': 'Vibrant Mexican street food and authentic tacos',
                'address': '78 Temple Bar, Dublin 2',
                'phone': '+353 1 234 5680',
                'website': 'https://tacofiesta.example.com',
                'rating': 4.7,
                'price_range': '€',
                'opening_hours': '10:00 AM - 11:00 PM',
                'location': Point(-6.266155, 53.345418, srid=4326)
            },
            {
                'name': 'Sakura Sushi',
                'cuisine_type': 'japanese',
                'description': 'Fresh sushi and traditional Japanese cuisine',
                'address': '12 Dame Street, Dublin 2',
                'phone': '+353 1 234 5681',
                'website': 'https://sakurasushi.example.com',
                'rating': 4.8,
                'price_range': '€€€',
                'opening_hours': '12:00 PM - 10:30 PM',
                'location': Point(-6.264455, 53.344214, srid=4326)
            },
            {
                'name': 'Spice of India',
                'cuisine_type': 'indian',
                'description': 'Aromatic Indian curries and tandoori specialties',
                'address': '34 South William Street, Dublin 2',
                'phone': '+353 1 234 5682',
                'website': 'https://spiceofindia.example.com',
                'rating': 4.4,
                'price_range': '€€',
                'opening_hours': '11:30 AM - 11:00 PM',
                'location': Point(-6.263210, 53.342805, srid=4326)
            },
            {
                'name': 'The Burger Joint',
                'cuisine_type': 'burger',
                'description': 'Gourmet burgers with premium beef',
                'address': '56 Camden Street, Dublin 2',
                'phone': '+353 1 234 5683',
                'website': 'https://burgerjoint.example.com',
                'rating': 4.6,
                'price_range': '€€',
                'opening_hours': '12:00 PM - 11:00 PM',
                'location': Point(-6.264892, 53.333919, srid=4326)
            },
            {
                'name': 'Quick Bites Fast Food',
                'cuisine_type': 'fast_food',
                'description': 'Fast food favorites',
                'address': '90 Henry Street, Dublin 1',
                'phone': '+353 1 234 5684',
                'website': '',
                'rating': 3.8,
                'price_range': '€',
                'opening_hours': '8:00 AM - 11:00 PM',
                'location': Point(-6.260745, 53.348917, srid=4326)
            },
            {
                'name': 'Café Mocha',
                'cuisine_type': 'cafe',
                'description': 'Artisan coffee and fresh pastries',
                'address': '23 Dawson Street, Dublin 2',
                'phone': '+353 1 234 5685',
                'website': 'https://cafemocha.example.com',
                'rating': 4.5,
                'price_range': '€',
                'opening_hours': '7:00 AM - 7:00 PM',
                'location': Point(-6.254892, 53.340919, srid=4326)
            },
            {
                'name': 'Pizza Paradise',
                'cuisine_type': 'pizza',
                'description': 'Wood-fired authentic Neapolitan pizzas',
                'address': '15 Exchequer Street, Dublin 2',
                'phone': '+353 1 234 5686',
                'website': 'https://pizzaparadise.example.com',
                'rating': 4.3,
                'price_range': '€€',
                'opening_hours': '11:00 AM - 11:00 PM',
                'location': Point(-6.262310, 53.342005, srid=4326)
            },
            {
                'name': 'Ocean Delights Seafood',
                'cuisine_type': 'seafood',
                'description': 'Fresh seafood daily',
                'address': '8 Howth Harbor, Dublin',
                'phone': '+353 1 234 5687',
                'website': 'https://oceandelights.example.com',
                'rating': 4.9,
                'price_range': '€€€',
                'opening_hours': '12:00 PM - 10:00 PM',
                'location': Point(-6.068389, 53.388611, srid=4326)
            },
            {
                'name': 'Green Garden Vegetarian',
                'cuisine_type': 'vegetarian',
                'description': 'Plant-based cuisine and vegan options',
                'address': '67 Georges Street, Dublin 2',
                'phone': '+353 1 234 5688',
                'website': 'https://greengarden.example.com',
                'rating': 4.6,
                'price_range': '€€',
                'opening_hours': '10:00 AM - 9:00 PM',
                'location': Point(-6.263892, 53.341919, srid=4326)
            },
            {
                'name': 'Thai Orchid Restaurant',
                'cuisine_type': 'thai',
                'description': 'Authentic Thai cuisine',
                'address': '89 Parnell Street, Dublin 1',
                'phone': '+353 1 234 5689',
                'website': 'https://thaiorchid.example.com',
                'rating': 4.4,
                'price_range': '€€',
                'opening_hours': '11:30 AM - 10:30 PM',
                'location': Point(-6.261445, 53.351214, srid=4326)
            },
            {
                'name': 'Mediterranean Breeze',
                'cuisine_type': 'mediterranean',
                'description': 'Mediterranean flavors and mezze platters',
                'address': '45 Capel Street, Dublin 1',
                'phone': '+353 1 234 5690',
                'website': 'https://medbreeze.example.com',
                'rating': 4.5,
                'price_range': '€€',
                'opening_hours': '12:00 PM - 11:00 PM',
                'location': Point(-6.267055, 53.347418, srid=4326)
            },
            {
                'name': 'American Diner Classic',
                'cuisine_type': 'american',
                'description': 'Classic American comfort food',
                'address': '23 Aungier Street, Dublin 2',
                'phone': '+353 1 234 5691',
                'website': 'https://americandiner.example.com',
                'rating': 4.1,
                'price_range': '€€',
                'opening_hours': '10:00 AM - 11:00 PM',
                'location': Point(-6.265310, 53.338805, srid=4326)
            },
            {
                'name': 'Bella Napoli Pizza',
                'cuisine_type': 'pizza',
                'description': 'Traditional Neapolitan pizza',
                'address': '12 Wicklow Street, Dublin 2',
                'phone': '+353 1 234 5692',
                'website': 'https://bellanapoli.example.com',
                'rating': 4.7,
                'price_range': '€€',
                'opening_hours': '11:00 AM - 11:30 PM',
                'location': Point(-6.259310, 53.343805, srid=4326)
            },
        ]

        # Bulk create all spots
        spots = [FoodSpot(**data) for data in spots_data]
        FoodSpot.objects.bulk_create(spots)
        
        total_created = FoodSpot.objects.count()
        
        self.stdout.write(
            self.style.SUCCESS(
                f'✅ Successfully loaded {total_created} food spots into the database!'
            )
        )
        
        # Display summary by cuisine
        self.stdout.write('\n📊 Summary by cuisine:')
        from django.db.models import Count
        summary = FoodSpot.objects.values('cuisine_type').annotate(count=Count('id')).order_by('-count')
        for item in summary:
            cuisine_display = dict(FoodSpot.CUISINE_CHOICES).get(item['cuisine_type'], item['cuisine_type'])
            self.stdout.write(f"   • {cuisine_display}: {item['count']} spot(s)")